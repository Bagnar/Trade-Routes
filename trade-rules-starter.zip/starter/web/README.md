# web/ — фронтенд

Создаётся на этапе 0 (Next.js + TypeScript). Источник структуры и стиля — `mockups/`:

- `index.html` — стартовая: фраза-запрос, маршрутизация, карточки коридоров.
- `corridor-china-canada.html` — страница коридора с режимом посылок.
- `corridor-russia-iran.html` — страница коридора с санкционной полосой и калькулятором на обе стороны.

Компоненты, которые нужно выделить из макетов: QuerySentence, StatusBand, SanctionsBand, SourceStamp, RatingCard, ProsCons, CompareTable, FactRow, CostCalculator, DocumentChecklist, SourcesTable, FollowPanel, ReportError.
Данные страницы приходят из таблицы `pages` (JSONB `content`) — фронтенд не собирает факты сам.
